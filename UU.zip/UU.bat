@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title UU远程校园网绕过工具 (定向防冲突版)

:: 1. 自动请求管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "INSTALL_DIR=C:\goodbyedpi"
set "BIN_DIR=%INSTALL_DIR%\goodbyedpi-0.2.3rc3-2\x86_64"
set "LIST_FILE=%BIN_DIR%\uu_list.txt"
set "ZIP_URL=https://github.com/ValdikSS/GoodbyeDPI/releases/download/0.2.3rc3/goodbyedpi-0.2.3rc3-2.zip"
set "ZIP_FILE=%INSTALL_DIR%\goodbyedpi.zip"
set "SVC_NAME=GoodbyeDPI_UU"
set "NEW_BIN_CMD=\"%BIN_DIR%\goodbyedpi.exe\" -e 1 --native-frag --blacklist \"%LIST_FILE%\""

:MENU
cls
echo ========================================================
echo       UU 远程校园网绕过工具 (定向防冲突版)
echo       仅针对网易系域名分片，降低对 CC Switch 等工具干扰
echo ========================================================
echo.
echo   [1] 临时启动 - 定向模式 (推荐，仅处理网易域名)
echo   [2] 安装/更新开机自启 - 定向模式 (适合宿舍被控端)
echo   [3] 卸载开机自启服务 (彻底停止并移除，兼容旧版)
echo   [4] 临时启动 - 全局模式 (仅当定向模式失效时备选)
echo   [0] 退出
echo.
set "choice="
set /p choice=请输入数字并回车: 

if "%choice%"=="1" goto RUN_TARGET
if "%choice%"=="2" goto INSTALL_TARGET
if "%choice%"=="3" goto UNINSTALL
if "%choice%"=="4" goto RUN_GLOBAL
if "%choice%"=="0" exit /b
goto MENU

:: ==========================================
:: 功能 1：临时启动 - 定向模式
:: ==========================================
:RUN_TARGET
call :ENSURE_FILES || goto MENU
call :PREPARE_LIST || goto MENU
call :STOP_CONFLICT_SVC || goto MENU
call :CHECK_TEMP_PROCESS || goto MENU
echo.
echo [运行中 - 定向模式] 仅对 163.com / netease.com 生效。
echo 请保持此窗口不要关闭，现在可以打开 UU 远程测试登录。
echo.
cd /d "%BIN_DIR%"
goodbyedpi.exe -e 1 --native-frag --blacklist "%LIST_FILE%"
if errorlevel 1 (
    echo.
    echo [错误] 程序异常退出，请检查是否被杀毒软件拦截 WinDivert 驱动。
)
pause
goto MENU

:: ==========================================
:: 功能 2：安装/更新开机自启 - 定向模式 (带失败回滚)
:: ==========================================
:INSTALL_TARGET
call :ENSURE_FILES || goto MENU
call :PREPARE_LIST || goto MENU

set "OLD_EXISTS=0"
set "OLD_RUNNING=0"
set "OLD_BINPATH="

sc query "%SVC_NAME%" >nul 2>&1
set "Q_ERR=!errorlevel!"
if "!Q_ERR!"=="0" (
    set "OLD_EXISTS=1"
    sc query "%SVC_NAME%" | findstr /i "RUNNING" >nul
    if not errorlevel 1 set "OLD_RUNNING=1"
    for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "(Get-CimInstance Win32_Service -Filter \"Name='%SVC_NAME%'\").PathName"`) do set "OLD_BINPATH=%%P"
) else if not "!Q_ERR!"=="1060" (
    echo.
    echo [失败] 查询现有服务状态出错，错误码: !Q_ERR!。
    pause
    goto MENU
)

if "!OLD_EXISTS!"=="1" (
    echo.
    echo [提示] 检测到已有服务 %SVC_NAME%，正在停止并准备原地更新...
    call :STOP_SERVICE_CORE
    if errorlevel 1 (
        echo.
        echo [失败] 无法停止旧服务，已取消更新，原有服务保持不变。
        pause
        goto MENU
    )
    call :CHECK_TEMP_PROCESS || (
        if "!OLD_RUNNING!"=="1" sc start "%SVC_NAME%" >nul 2>&1
        goto MENU
    )
    sc config "%SVC_NAME%" binPath= "%NEW_BIN_CMD%" start= auto >nul 2>&1
    set "CFG_ERR=!errorlevel!"
    if not "!CFG_ERR!"=="0" (
        echo.
        echo [失败] 更新服务配置失败，错误码: !CFG_ERR!，正在恢复原服务状态...
        if "!OLD_RUNNING!"=="1" sc start "%SVC_NAME%" >nul 2>&1
        pause
        goto MENU
    )
) else (
    call :CHECK_TEMP_PROCESS || goto MENU
    echo.
    echo 正在创建定向模式开机自启服务...
    sc create "%SVC_NAME%" binPath= "%NEW_BIN_CMD%" start= auto >nul 2>&1
    set "CREATE_ERR=!errorlevel!"
    if not "!CREATE_ERR!"=="0" (
        echo.
        echo [失败] 创建服务失败，错误码: !CREATE_ERR!。请检查权限或重启电脑后重试。
        pause
        goto MENU
    )
)

sc start "%SVC_NAME%" >nul 2>&1
set "START_ERR=!errorlevel!"
if not "!START_ERR!"=="0" (
    echo.
    echo [失败] 服务启动失败，错误码: !START_ERR!。请检查杀毒软件是否拦截 WinDivert64.sys。
    call :ROLLBACK_SERVICE
    pause
    goto MENU
)

echo.
echo [校验中] 正在等待驱动初始化并验证服务稳定性，约需 22 秒，请勿关闭窗口...
set "STABLE=1"
for /l %%i in (1,1,11) do (
    timeout /t 2 /nobreak >nul
    sc query "%SVC_NAME%" | findstr /i "RUNNING" >nul
    if errorlevel 1 (
        set "STABLE=0"
        goto CHECK_STABLE_DONE
    )
)

:CHECK_STABLE_DONE
if "!STABLE!"=="1" (
    echo.
    echo [成功] 定向模式开机自启服务已通过稳定性校验并正在运行！现在可以关闭本窗口。
) else (
    echo.
    echo [失败] 服务在驱动初始化阶段异常退出，请尝试用选项 [1] 查看具体报错。
    call :ROLLBACK_SERVICE
)
pause
goto MENU

:: ==========================================
:: 功能 3：卸载开机自启服务 (离线可用)
:: ==========================================
:UNINSTALL
echo.
echo 正在检查并卸载后台服务 %SVC_NAME% ...
sc query "%SVC_NAME%" >nul 2>&1
set "Q_ERR=!errorlevel!"
if "!Q_ERR!"=="1060" (
    echo [提示] 当前未安装 %SVC_NAME% 服务，无需卸载。
    pause
    goto MENU
)
if not "!Q_ERR!"=="0" (
    echo [失败] 查询服务状态失败，错误码: !Q_ERR!。
    pause
    goto MENU
)

call :REMOVE_SERVICE_CORE
set "REM_RES=!errorlevel!"

if "!REM_RES!"=="0" (
    echo.
    echo [成功] 后台服务已彻底停止并卸载！
)
if "!REM_RES!"=="1" (
    echo.
    echo [失败] 卸载服务时发生错误，请查看上方具体错误提示。
)
if "!REM_RES!"=="2" (
    echo.
    echo [提示] 服务已标记为删除，但仍有系统句柄未释放，重启电脑后将彻底消失。
)
pause
goto MENU

:: ==========================================
:: 功能 4：临时启动 - 全局模式
:: ==========================================
:RUN_GLOBAL
call :ENSURE_FILES || goto MENU
call :STOP_CONFLICT_SVC || goto MENU
call :CHECK_TEMP_PROCESS || goto MENU
echo.
echo [运行中 - 全局模式] 已开启全局本地分片，请保持此窗口不要关闭。
echo 注意：全局模式可能干扰 CC Switch 等工具，不用时请关闭本窗口。
echo.
cd /d "%BIN_DIR%"
goodbyedpi.exe -e 1 --native-frag
if errorlevel 1 (
    echo.
    echo [错误] 程序异常退出，请检查是否被杀毒软件拦截 WinDivert 驱动。
)
pause
goto MENU

:: ==========================================
:: 子程序：原子下载、校验 ZIP 结构并检查 3 个核心文件
:: ==========================================
:ENSURE_FILES
set "NEED_DL=0"
if not exist "%BIN_DIR%\goodbyedpi.exe" set "NEED_DL=1"
if not exist "%BIN_DIR%\WinDivert.dll" set "NEED_DL=1"
if not exist "%BIN_DIR%\WinDivert64.sys" set "NEED_DL=1"

if "%NEED_DL%"=="0" exit /b 0

echo.
echo [提示] 检测到核心文件缺失或不完整，准备下载或解压...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

if not exist "%ZIP_FILE%" (
    echo [1/2] 正在从 GitHub 下载 GoodbyeDPI ...
    del "%ZIP_FILE%.tmp" >nul 2>&1
    curl.exe -fL --connect-timeout 15 -o "%ZIP_FILE%.tmp" "%ZIP_URL%"
    if errorlevel 1 (
        echo.
        echo [错误] 下载失败，可能是校园网暂时连不上 GitHub。
        echo 请手动下载 goodbyedpi-0.2.3rc3-2.zip，改名为 goodbyedpi.zip 放入 C:\goodbyedpi\ 后重试。
        del "%ZIP_FILE%.tmp" >nul 2>&1
        pause
        exit /b 1
    )
    for %%A in ("%ZIP_FILE%.tmp") do set "TMP_SIZE=%%~zA"
    if "!TMP_SIZE!"=="0" (
        echo.
        echo [错误] 下载得到空文件，已清理，请检查网络后重试。
        del "%ZIP_FILE%.tmp" >nul 2>&1
        pause
        exit /b 1
    )
    move /y "%ZIP_FILE%.tmp" "%ZIP_FILE%" >nul 2>&1
)

echo [2/2] 正在校验压缩包结构并解压...
powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; try { $z=[System.IO.Compression.ZipFile]::OpenRead('%ZIP_FILE%'); $n=$z.Entries.FullName; $z.Dispose() } catch { exit 1 }; $req=@('goodbyedpi-0.2.3rc3-2/x86_64/goodbyedpi.exe','goodbyedpi-0.2.3rc3-2/x86_64/WinDivert.dll','goodbyedpi-0.2.3rc3-2/x86_64/WinDivert64.sys'); if(($req | Where-Object {$n -notcontains $_}).Count -gt 0){ exit 2 }"
set "ZIP_CHK=!errorlevel!"
if "!ZIP_CHK!"=="1" (
    echo.
    echo [错误] 压缩包已损坏，无法读取。已自动删除损坏文件，请重新运行下载。
    del "%ZIP_FILE%" >nul 2>&1
    pause
    exit /b 1
)
if "!ZIP_CHK!"=="2" (
    echo.
    echo [错误] 压缩包内缺少预期目录结构或核心文件，可能是手动放入了错误版本的压缩包。
    echo 已自动删除该压缩包，请重新运行以自动下载正确版本。
    del "%ZIP_FILE%" >nul 2>&1
    pause
    exit /b 1
)

powershell -NoProfile -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%INSTALL_DIR%' -Force"
if errorlevel 1 (
    echo.
    echo [错误] 压缩包解压失败，请检查磁盘空间或杀毒软件拦截。
    pause
    exit /b 1
)

if not exist "%BIN_DIR%\goodbyedpi.exe" goto DRIVER_MISSING
if not exist "%BIN_DIR%\WinDivert.dll" goto DRIVER_MISSING
if not exist "%BIN_DIR%\WinDivert64.sys" goto DRIVER_MISSING

del "%ZIP_FILE%" >nul 2>&1
exit /b 0

:DRIVER_MISSING
echo.
echo [错误] 压缩包结构正常，但解压后缺少 exe 或 WinDivert 驱动文件。
echo 这通常是因为 Windows 安全中心或杀毒软件拦截了 WinDivert64.sys，请放行后重试。
pause
exit /b 1

:: ==========================================
:: 子程序：写入并校验定向域名名单
:: ==========================================
:PREPARE_LIST
if not exist "%BIN_DIR%" (
    echo [错误] 运行目录不存在: %BIN_DIR%
    pause
    exit /b 1
)
set "TMP_LIST=%LIST_FILE%.tmp"
(
echo 163.com
echo netease.com
) > "%TMP_LIST%" 2>nul

findstr /x /c:"163.com" "%TMP_LIST%" >nul 2>&1 || goto LIST_FAIL
findstr /x /c:"netease.com" "%TMP_LIST%" >nul 2>&1 || goto LIST_FAIL
move /y "%TMP_LIST%" "%LIST_FILE%" >nul 2>&1 || goto LIST_FAIL
if not exist "%LIST_FILE%" goto LIST_FAIL
exit /b 0

:LIST_FAIL
del "%TMP_LIST%" >nul 2>&1
echo.
echo [错误] 无法写入或校验定向域名名单 %LIST_FILE%，请检查目录权限或杀毒软件限制。
pause
exit /b 1

:: ==========================================
:: 子程序：检测其他窗口中已运行的临时实例
:: ==========================================
:CHECK_TEMP_PROCESS
tasklist /fi "imagename eq goodbyedpi.exe" /fo csv /nh 2>nul | findstr /i "goodbyedpi.exe" >nul
if errorlevel 1 exit /b 0

echo.
echo [警告] 检测到系统中已有另一个 goodbyedpi.exe 进程正在运行！
echo 这通常是你在其他窗口开启了临时启动模式，例如全局模式。
echo 为避免多实例冲突或继续干扰 CC Switch，请先关闭那个黑色运行窗口，再重新操作。
pause
exit /b 1

:: ==========================================
:: 子程序：安装/更新失败时回滚服务
:: ==========================================
:ROLLBACK_SERVICE
if "!OLD_EXISTS!"=="1" (
    echo [回滚] 正在恢复更新前的原有服务配置...
    call :STOP_SERVICE_CORE >nul 2>&1
    if defined OLD_BINPATH (
        set "ESC_OLD_BIN=!OLD_BINPATH:"=\"!"
        sc config "%SVC_NAME%" binPath= "!ESC_OLD_BIN!" >nul 2>&1
    )
    if "!OLD_RUNNING!"=="1" (
        sc start "%SVC_NAME%" >nul 2>&1
        if errorlevel 1 (
            echo [警告] 原配置已恢复，但自动重启原服务失败，请手动检查服务状态。
        ) else (
            echo [回滚完成] 已恢复原有服务并重新启动。
        )
    ) else (
        echo [回滚完成] 已恢复原有服务配置。
    )
) else (
    echo [清理] 正在移除本次未能正常启动的新建服务...
    call :REMOVE_SERVICE_CORE >nul 2>&1
)
exit /b 0

:: ==========================================
:: 子程序：临时启动前检测并确认停止已有后台服务
:: ==========================================
:STOP_CONFLICT_SVC
sc query "%SVC_NAME%" >nul 2>&1
set "Q_ERR=!errorlevel!"
if "!Q_ERR!"=="1060" exit /b 0
if not "!Q_ERR!"=="0" (
    echo.
    echo [错误] 检测后台服务状态失败，错误码: !Q_ERR!。
    pause
    exit /b 1
)

sc query "%SVC_NAME%" | findstr /i "STOPPED" >nul
if not errorlevel 1 exit /b 0

echo.
echo [警告] 检测到后台服务 %SVC_NAME% 正在运行，可能是旧版全局服务。
echo 正在停止该后台服务并等待其完全退出...
call :STOP_SERVICE_CORE
if errorlevel 1 (
    echo.
    echo [失败] 无法在规定时间内停止后台服务 %SVC_NAME%，为避免与新实例冲突，已取消启动！
    echo 请先尝试使用菜单选项 [3] 卸载旧服务，或重启电脑后再试。
    pause
    exit /b 1
)

echo [提示] 后台服务已确认停止。如需永久替换为定向版，请返回菜单选 [2]。
exit /b 0

:: ==========================================
:: 子程序：停止服务并轮询确认达到 STOPPED 状态
:: ==========================================
:STOP_SERVICE_CORE
sc query "%SVC_NAME%" >nul 2>&1
set "Q_ERR=!errorlevel!"
if "!Q_ERR!"=="1060" exit /b 0
if not "!Q_ERR!"=="0" (
    echo [错误] 查询服务状态失败，错误码: !Q_ERR!
    exit /b 1
)

sc query "%SVC_NAME%" | findstr /i "STOPPED" >nul
if not errorlevel 1 exit /b 0

sc stop "%SVC_NAME%" >nul 2>&1
set "STOP_ERR=!errorlevel!"
if not "!STOP_ERR!"=="0" (
    if not "!STOP_ERR!"=="1061" (
        if not "!STOP_ERR!"=="1062" (
            echo [错误] 发送停止指令失败，sc stop 错误码: !STOP_ERR!
            exit /b 1
        )
    )
)

for /l %%i in (1,1,8) do (
    sc query "%SVC_NAME%" >nul 2>&1
    if "!errorlevel!"=="1060" exit /b 0
    sc query "%SVC_NAME%" | findstr /i "STOPPED" >nul
    if not errorlevel 1 exit /b 0
    timeout /t 1 /nobreak >nul
)

echo [错误] 等待服务停止超时，8 秒内未进入 STOPPED 状态。
exit /b 1

:: ==========================================
:: 子程序：停止并轮询等待服务彻底删除
:: ==========================================
:REMOVE_SERVICE_CORE
sc query "%SVC_NAME%" >nul 2>&1
set "Q_ERR=!errorlevel!"
if "!Q_ERR!"=="1060" exit /b 0
if not "!Q_ERR!"=="0" (
    echo [错误] 查询服务失败，错误码: !Q_ERR!
    exit /b 1
)

call :STOP_SERVICE_CORE
if errorlevel 1 exit /b 1

sc delete "%SVC_NAME%" >nul 2>&1
set "DEL_ERR=!errorlevel!"
if not "!DEL_ERR!"=="0" (
    if not "!DEL_ERR!"=="1072" (
        echo [错误] 删除服务失败，sc delete 错误码: !DEL_ERR!
        exit /b 1
    )
)

for /l %%i in (1,1,6) do (
    sc query "%SVC_NAME%" >nul 2>&1
    if "!errorlevel!"=="1060" exit /b 0
    timeout /t 1 /nobreak >nul
)

exit /b 2