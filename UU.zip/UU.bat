@echo off
chcp 65001 >nul
title UU远程校园网绕过工具 (GoodbyeDPI)

:: 1. 自动请求管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "INSTALL_DIR=C:\goodbyedpi"
set "BIN_DIR=%INSTALL_DIR%\goodbyedpi-0.2.3rc3-2\x86_64"
set "ZIP_URL=https://github.com/ValdikSS/GoodbyeDPI/releases/download/0.2.3rc3/goodbyedpi-0.2.3rc3-2.zip"
set "ZIP_FILE=%INSTALL_DIR%\goodbyedpi.zip"

:: 2. 自动下载并解压
if not exist "%BIN_DIR%\goodbyedpi.exe" (
    if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

    if not exist "%ZIP_FILE%" (
        echo [1/2] 正在从 GitHub 下载 GoodbyeDPI ...
        curl.exe -fL --connect-timeout 15 -o "%ZIP_FILE%" "%ZIP_URL%"
        if errorlevel 1 (
            echo.
            echo [错误] 下载失败，可能是校园网暂时连不上 GitHub。
            echo 请手动下载 goodbyedpi-0.2.3rc3-2.zip，改名为 goodbyedpi.zip 放入 C:\goodbyedpi\ 后重新运行。
            del "%ZIP_FILE%" >nul 2>&1
            pause
            exit /b
        )
    )

    echo [2/2] 正在解压文件...
    powershell -NoProfile -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%INSTALL_DIR%' -Force"
    if not exist "%BIN_DIR%\goodbyedpi.exe" (
        echo.
        echo [错误] 解压失败，或文件被 Windows 安全中心拦截。
        echo 请检查杀毒软件拦截记录并允许放行后重试。
        pause
        exit /b
    )
    del "%ZIP_FILE%" >nul 2>&1
)

:MENU
cls
echo ==================================================
echo        UU 远程校园网绕过工具 (GoodbyeDPI)
echo        纯本地直连分片，无需翻墙，不改系统代理
echo ==================================================
echo.
echo   [1] 临时启动 (测试用，关闭本窗口即停止)
echo   [2] 安装开机自启服务 (适合宿舍被控端长期使用)
echo   [3] 卸载开机自启服务 (彻底还原)
echo   [0] 退出
echo.
set /p choice=请输入数字并回车: 

if "%choice%"=="1" goto RUN
if "%choice%"=="2" goto INSTALL
if "%choice%"=="3" goto UNINSTALL
if "%choice%"=="0" exit /b
goto MENU

:RUN
echo.
echo [运行中] 已开启本地分片，请保持此窗口不要关闭，现在可以打开 UU 远程登录。
echo (不用时直接关闭本窗口即可停止)
echo.
cd /d "%BIN_DIR%"
goodbyedpi.exe -e 1 --native-frag
pause
goto MENU

:INSTALL
echo.
echo 正在安装开机自启后台服务...
sc stop GoodbyeDPI_UU >nul 2>&1
sc delete GoodbyeDPI_UU >nul 2>&1
sc create "GoodbyeDPI_UU" binPath= "\"%BIN_DIR%\goodbyedpi.exe\" -e 1 --native-frag" start= "auto"
sc start "GoodbyeDPI_UU"
echo.
echo [完成] 已设为开机自启后台服务，现在可以关闭本窗口，电脑重启后也会自动生效。
pause
goto MENU

:UNINSTALL
echo.
echo 正在停止并卸载后台服务...
sc stop GoodbyeDPI_UU
sc delete GoodbyeDPI_UU
echo.
echo [完成] 后台服务已彻底卸载。
pause
goto MENU